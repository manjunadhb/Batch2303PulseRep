
import "./App.css";

function App() {
  return (
    <div className="App">
      <h1>This line is added by Manjunadh from Github.com</h1>
      <h1>This second line is added by Manjunadh from local repository</h1>
      <h1>This third line is added by Veera</h1>
      <h1>This line is added by Deepika</h1>
    </div>
  );
}

export default App;
